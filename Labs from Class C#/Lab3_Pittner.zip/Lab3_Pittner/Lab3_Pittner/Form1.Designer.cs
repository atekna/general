﻿namespace Lab3_Pittner
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.LBL_ApplicantName = new System.Windows.Forms.Label();
            this.LBL_HomePrice = new System.Windows.Forms.Label();
            this.LBL_Downpayment = new System.Windows.Forms.Label();
            this.LBL_InterestRate = new System.Windows.Forms.Label();
            this.LBL_LoanTerm = new System.Windows.Forms.Label();
            this.LBL_FinanceAmount = new System.Windows.Forms.Label();
            this.LBL_Monthly = new System.Windows.Forms.Label();
            this.TXT_ApplicantName = new System.Windows.Forms.TextBox();
            this.TXT_HomePrice = new System.Windows.Forms.TextBox();
            this.TXT_Downpayment = new System.Windows.Forms.TextBox();
            this.TXT_InterestRate = new System.Windows.Forms.TextBox();
            this.TXT_LoanTerm = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.BTN_Exit = new System.Windows.Forms.Button();
            this.BTN_Calc = new System.Windows.Forms.Button();
            this.LBL_txt_special_monthlyPay = new System.Windows.Forms.Label();
            this.LBL_txt_special_theLoanAmt = new System.Windows.Forms.Label();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.SuspendLayout();
            // 
            // LBL_ApplicantName
            // 
            this.LBL_ApplicantName.AutoSize = true;
            this.LBL_ApplicantName.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBL_ApplicantName.Location = new System.Drawing.Point(189, 105);
            this.LBL_ApplicantName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LBL_ApplicantName.Name = "LBL_ApplicantName";
            this.LBL_ApplicantName.Size = new System.Drawing.Size(197, 26);
            this.LBL_ApplicantName.TabIndex = 0;
            this.LBL_ApplicantName.Text = "Name of Applicant:";
            // 
            // LBL_HomePrice
            // 
            this.LBL_HomePrice.AutoSize = true;
            this.LBL_HomePrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBL_HomePrice.Location = new System.Drawing.Point(155, 174);
            this.LBL_HomePrice.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LBL_HomePrice.Name = "LBL_HomePrice";
            this.LBL_HomePrice.Size = new System.Drawing.Size(231, 26);
            this.LBL_HomePrice.TabIndex = 1;
            this.LBL_HomePrice.Text = "Home Purchase Price:";
            // 
            // LBL_Downpayment
            // 
            this.LBL_Downpayment.AutoSize = true;
            this.LBL_Downpayment.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBL_Downpayment.Location = new System.Drawing.Point(146, 220);
            this.LBL_Downpayment.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LBL_Downpayment.Name = "LBL_Downpayment";
            this.LBL_Downpayment.Size = new System.Drawing.Size(240, 26);
            this.LBL_Downpayment.TabIndex = 2;
            this.LBL_Downpayment.Text = "Downpayment Amount:";
            // 
            // LBL_InterestRate
            // 
            this.LBL_InterestRate.AutoSize = true;
            this.LBL_InterestRate.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBL_InterestRate.Location = new System.Drawing.Point(176, 379);
            this.LBL_InterestRate.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LBL_InterestRate.Name = "LBL_InterestRate";
            this.LBL_InterestRate.Size = new System.Drawing.Size(210, 26);
            this.LBL_InterestRate.TabIndex = 3;
            this.LBL_InterestRate.Text = "Annual Interest Rate";
            // 
            // LBL_LoanTerm
            // 
            this.LBL_LoanTerm.AutoSize = true;
            this.LBL_LoanTerm.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBL_LoanTerm.Location = new System.Drawing.Point(240, 458);
            this.LBL_LoanTerm.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LBL_LoanTerm.Name = "LBL_LoanTerm";
            this.LBL_LoanTerm.Size = new System.Drawing.Size(146, 26);
            this.LBL_LoanTerm.TabIndex = 4;
            this.LBL_LoanTerm.Text = "Term of Loan:";
            // 
            // LBL_FinanceAmount
            // 
            this.LBL_FinanceAmount.AutoSize = true;
            this.LBL_FinanceAmount.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBL_FinanceAmount.Location = new System.Drawing.Point(934, 171);
            this.LBL_FinanceAmount.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LBL_FinanceAmount.Name = "LBL_FinanceAmount";
            this.LBL_FinanceAmount.Size = new System.Drawing.Size(172, 26);
            this.LBL_FinanceAmount.TabIndex = 5;
            this.LBL_FinanceAmount.Text = "Amount of Loan:";
            // 
            // LBL_Monthly
            // 
            this.LBL_Monthly.AutoSize = true;
            this.LBL_Monthly.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBL_Monthly.Location = new System.Drawing.Point(815, 220);
            this.LBL_Monthly.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LBL_Monthly.Name = "LBL_Monthly";
            this.LBL_Monthly.Size = new System.Drawing.Size(291, 26);
            this.LBL_Monthly.TabIndex = 6;
            this.LBL_Monthly.Text = "Estimated Monthly Payment:";
            // 
            // TXT_ApplicantName
            // 
            this.TXT_ApplicantName.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TXT_ApplicantName.Location = new System.Drawing.Point(483, 102);
            this.TXT_ApplicantName.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.TXT_ApplicantName.Name = "TXT_ApplicantName";
            this.TXT_ApplicantName.Size = new System.Drawing.Size(256, 32);
            this.TXT_ApplicantName.TabIndex = 7;
            // 
            // TXT_HomePrice
            // 
            this.TXT_HomePrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TXT_HomePrice.Location = new System.Drawing.Point(483, 165);
            this.TXT_HomePrice.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.TXT_HomePrice.Name = "TXT_HomePrice";
            this.TXT_HomePrice.Size = new System.Drawing.Size(256, 32);
            this.TXT_HomePrice.TabIndex = 8;
            // 
            // TXT_Downpayment
            // 
            this.TXT_Downpayment.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TXT_Downpayment.Location = new System.Drawing.Point(483, 214);
            this.TXT_Downpayment.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.TXT_Downpayment.Name = "TXT_Downpayment";
            this.TXT_Downpayment.Size = new System.Drawing.Size(256, 32);
            this.TXT_Downpayment.TabIndex = 9;
            // 
            // TXT_InterestRate
            // 
            this.TXT_InterestRate.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TXT_InterestRate.Location = new System.Drawing.Point(483, 376);
            this.TXT_InterestRate.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.TXT_InterestRate.Name = "TXT_InterestRate";
            this.TXT_InterestRate.Size = new System.Drawing.Size(256, 32);
            this.TXT_InterestRate.TabIndex = 10;
            // 
            // TXT_LoanTerm
            // 
            this.TXT_LoanTerm.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TXT_LoanTerm.Location = new System.Drawing.Point(483, 455);
            this.TXT_LoanTerm.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.TXT_LoanTerm.Name = "TXT_LoanTerm";
            this.TXT_LoanTerm.Size = new System.Drawing.Size(256, 32);
            this.TXT_LoanTerm.TabIndex = 11;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Gainsboro;
            this.panel1.Controls.Add(this.BTN_Exit);
            this.panel1.Controls.Add(this.BTN_Calc);
            this.panel1.Location = new System.Drawing.Point(194, 612);
            this.panel1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1209, 154);
            this.panel1.TabIndex = 14;
            // 
            // BTN_Exit
            // 
            this.BTN_Exit.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTN_Exit.Location = new System.Drawing.Point(927, 62);
            this.BTN_Exit.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.BTN_Exit.Name = "BTN_Exit";
            this.BTN_Exit.Size = new System.Drawing.Size(177, 60);
            this.BTN_Exit.TabIndex = 1;
            this.BTN_Exit.Text = "Exit";
            this.BTN_Exit.UseVisualStyleBackColor = true;
            this.BTN_Exit.Click += new System.EventHandler(this.BTN_Exit_Click);
            // 
            // BTN_Calc
            // 
            this.BTN_Calc.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTN_Calc.Location = new System.Drawing.Point(82, 62);
            this.BTN_Calc.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.BTN_Calc.Name = "BTN_Calc";
            this.BTN_Calc.Size = new System.Drawing.Size(177, 60);
            this.BTN_Calc.TabIndex = 0;
            this.BTN_Calc.Text = "Calculate";
            this.BTN_Calc.UseVisualStyleBackColor = true;
            this.BTN_Calc.Click += new System.EventHandler(this.BTN_Calc_Click);
            // 
            // LBL_txt_special_monthlyPay
            // 
            this.LBL_txt_special_monthlyPay.BackColor = System.Drawing.Color.White;
            this.LBL_txt_special_monthlyPay.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.LBL_txt_special_monthlyPay.Location = new System.Drawing.Point(1191, 213);
            this.LBL_txt_special_monthlyPay.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LBL_txt_special_monthlyPay.Name = "LBL_txt_special_monthlyPay";
            this.LBL_txt_special_monthlyPay.Size = new System.Drawing.Size(256, 33);
            this.LBL_txt_special_monthlyPay.TabIndex = 15;
            // 
            // LBL_txt_special_theLoanAmt
            // 
            this.LBL_txt_special_theLoanAmt.BackColor = System.Drawing.Color.White;
            this.LBL_txt_special_theLoanAmt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.LBL_txt_special_theLoanAmt.Location = new System.Drawing.Point(1191, 164);
            this.LBL_txt_special_theLoanAmt.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LBL_txt_special_theLoanAmt.Name = "LBL_txt_special_theLoanAmt";
            this.LBL_txt_special_theLoanAmt.Size = new System.Drawing.Size(256, 33);
            this.LBL_txt_special_theLoanAmt.TabIndex = 16;
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.ClientSize = new System.Drawing.Size(1575, 785);
            this.Controls.Add(this.LBL_txt_special_theLoanAmt);
            this.Controls.Add(this.LBL_txt_special_monthlyPay);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.TXT_LoanTerm);
            this.Controls.Add(this.TXT_InterestRate);
            this.Controls.Add(this.TXT_Downpayment);
            this.Controls.Add(this.TXT_HomePrice);
            this.Controls.Add(this.TXT_ApplicantName);
            this.Controls.Add(this.LBL_Monthly);
            this.Controls.Add(this.LBL_FinanceAmount);
            this.Controls.Add(this.LBL_LoanTerm);
            this.Controls.Add(this.LBL_InterestRate);
            this.Controls.Add(this.LBL_Downpayment);
            this.Controls.Add(this.LBL_HomePrice);
            this.Controls.Add(this.LBL_ApplicantName);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "Form1";
            this.Text = "Mortgage Applicant Calculator";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LBL_ApplicantName;
        private System.Windows.Forms.Label LBL_HomePrice;
        private System.Windows.Forms.Label LBL_Downpayment;
        private System.Windows.Forms.Label LBL_InterestRate;
        private System.Windows.Forms.Label LBL_LoanTerm;
        private System.Windows.Forms.Label LBL_FinanceAmount;
        private System.Windows.Forms.Label LBL_Monthly;
        private System.Windows.Forms.TextBox TXT_ApplicantName;
        private System.Windows.Forms.TextBox TXT_HomePrice;
        private System.Windows.Forms.TextBox TXT_Downpayment;
        private System.Windows.Forms.TextBox TXT_InterestRate;
        private System.Windows.Forms.TextBox TXT_LoanTerm;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button BTN_Exit;
        private System.Windows.Forms.Button BTN_Calc;
        private System.Windows.Forms.Label LBL_txt_special_monthlyPay;
        private System.Windows.Forms.Label LBL_txt_special_theLoanAmt;
        private System.Windows.Forms.ErrorProvider errorProvider1;
    }
}

