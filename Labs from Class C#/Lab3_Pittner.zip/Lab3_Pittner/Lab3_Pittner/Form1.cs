﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//1 text box, 1 button control min.
//display error mssg with messagebox.show()
//output calculated values
//validate check each field
//the name, the agreed purchase pruce, buyer dwnpayment, loan APR, life of the loan
//2 read only fields: result that is the monthly payment, result that is purchase price - downpaymnt (AKA loan amount)
// monthlyPayment = interest rate*loan amount*(1+loan amount)^n/(1+loan amount)^n-1


namespace Lab3_Pittner
{
    public partial class Form1 : Form
    {



        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
           
        }




        //OPTION 1 ---- Calculate
        private void BTN_Calc_Click(object sender, EventArgs e)
        {



            //validations
            bool validHomePrice = double.TryParse(TXT_HomePrice.Text, out double homePrice);
            bool validDownpayment = double.TryParse(TXT_Downpayment.Text, out double downPay);
            bool validInterestRate = double.TryParse(TXT_InterestRate.Text, out double iRate);
            bool validLoanTerm = int.TryParse(TXT_LoanTerm.Text, out int term);

            if (TXT_ApplicantName.Text == "" || TXT_HomePrice.Text == "" || TXT_Downpayment.Text == "" || TXT_InterestRate.Text ==""||
                TXT_LoanTerm.Text=="")
            {
                DialogResult icalc;
                icalc = MessageBox.Show("Please ensure all fields have valid input.", "Mortgage Applicant Calculator");
            }

            else if (!validHomePrice)
            {
                MessageBox.Show("Invalid data for Home Price", "Warning");
                //TXT_HomePrice.BackColor = Color.MistyRose;
                return;
            }

            else if (!validDownpayment)
            {
                MessageBox.Show("Invalid data for DownPayment", "Warning");
                //TXT_HomePrice.BackColor = Color.MistyRose;
                return;
            }

            else if (!validInterestRate)
            {
                MessageBox.Show("Invalid data for Interest Rate", "Warning");
                //TXT_HomePrice.BackColor = Color.MistyRose;
                return;
            }

            else if (!validLoanTerm)
            {
                MessageBox.Show("Invalid data for Loan Term", "Warning");
                //TXT_HomePrice.BackColor = Color.MistyRose;
                return;
            }



            //else do the calculations if valid
            else
            {

                double purchasePrice = Convert.ToDouble(TXT_HomePrice.Text);
                double downPaymentAmount = Convert.ToDouble(TXT_Downpayment.Text);
                int lengthOfLoan = Convert.ToInt32(TXT_LoanTerm.Text);
                double theRate = Convert.ToDouble(TXT_InterestRate.Text);

                double financing = (purchasePrice - downPaymentAmount);
                string stringFinancing = String.Format("{0:C}", financing);
                LBL_txt_special_theLoanAmt.Text = (stringFinancing);

                
                double powerN = lengthOfLoan;
                double monthlyInterestRate = (theRate / 12)/100;
                double formula1 = (monthlyInterestRate * financing) * Math.Pow(1 + monthlyInterestRate, powerN);
                double formula2 = Math.Pow((1 + monthlyInterestRate),powerN) - 1;
                double result = formula1 / formula2;
                string stringResult = String.Format("{0:C}", result);
                LBL_txt_special_monthlyPay.Text = (stringResult);




            }


        }



        //OPTION 2 ----- Exit
        private void BTN_Exit_Click(object sender, EventArgs e)
        {
            DialogResult iExit;
            iExit = MessageBox.Show("Would you like to exit the program?", "Mortgage Applicant Calculator", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (iExit == DialogResult.Yes)
            {
                Application.Exit();
            }
        }








        //---------------------------------------------------
        //THIS REFUSES TO GO AWAY
        private void TXT_LoanTerm_TextChanged(object sender, EventArgs e)
        {
            //I give up. I can't get this to be deleted in properties. I hate windows forms.
            //Everything else would delete just fine under the lightning bolt except for this.
        }
    }
}
