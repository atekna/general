﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//Wanted to see if there was a more compact way to do calculations. Couldn't think of any that would really be incredibly shorter outside
//of using a class to avoid repetition.

namespace Lab2Pittner
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello. Welcome to Tax Calculator for Single-Filer Status.");
            Console.WriteLine("Please Enter your income for the tax year");
            string userIncome = Console.ReadLine();
            double userIncomeConverted = Convert.ToDouble(userIncome);
           



            //PROGRAM
            double youPay;

            //COULD not get this to work. WAnted to test if after the string userIncome was converted to DOUBLE userIncomeConverted, it was a valid entry. If not, program terminates.
            //IF it was a valid entry, was using the required structure to test conditions via IF, through the Else condition of it being valid.

            //if (!double.TryParse(Console.ReadLine(), out userIncomeConverted))
            //{
                //Console.WriteLine("There was a problem with the value you entered. Program will now terminate.");
                //Console.Read();
            //}

            //else
            //{
                if (userIncomeConverted <= 9325.00 && userIncomeConverted != 0)
                {
                    Console.WriteLine("Your income was {0:C}", userIncomeConverted);
                    youPay = (userIncomeConverted * 0.1);
                    Console.WriteLine("Tax Bracket is 10%.");
                    Console.Write("You pay ");
                    Console.WriteLine("{0:C}", youPay);

                }

                else if (userIncomeConverted >= 9325.01 && userIncomeConverted <= 37950.99)
                {
                    Console.WriteLine("Your income was {0:C}", userIncomeConverted);
                    double adjusted1 = userIncomeConverted - 9325.00;
                    double youPay10 = 9325.00 * 0.1;
                    double youPay15 = adjusted1 * .15;
                    double finalPay = youPay10 + youPay15;
                    Console.WriteLine("Tax Bracket is 15%.");
                    Console.Write("You pay ");
                    Console.WriteLine("{0:C}", finalPay );
                }

                else if (userIncomeConverted >= 37951.00 && userIncomeConverted <= 91900.99)
                {
                    Console.WriteLine("Your income was {0:C}", userIncomeConverted);
                    double adjusted1 = userIncomeConverted - 9325.00;
                    double adjusted2 = userIncomeConverted - 28625.00;
                    double youPay10 = 9325.00 * 0.1;
                    double youPay15 = 28625.00 * .15;
                    double youPay25 = adjusted2 * .25;
                    double finalPay = (youPay10 + youPay15 + youPay25);
                    Console.WriteLine("Tax Bracket is 25%.");
                    Console.Write("You pay ");
                    Console.WriteLine("{0:C}", finalPay);
                }

                else if (userIncomeConverted >= 91901.00 && userIncomeConverted <= 191650.99)
                {
                    double adjusted1 = userIncomeConverted - 9325.00;
                    double adjusted2 = userIncomeConverted - 28625.00;
                    double adjusted3 = userIncomeConverted - 53950.00;
                    double youPay10 = 9325.00 * 0.1;
                    double youPay15 = 28625.00 * .15;
                    double youPay25 = adjusted2 * .25;
                    double youPay28 = adjusted3 * .28;
                    double finalPay = (youPay10 + youPay15 + youPay25+ youPay28);
                    Console.WriteLine("Your income was {0:C}", userIncomeConverted);
                    youPay = (userIncomeConverted * 0.28);
                    Console.WriteLine("Tax Bracket is 28%.");
                    Console.Write("You pay ");
                    Console.WriteLine("{0:C}", youPay);
                }

                else if (userIncomeConverted >= 191651.00 && userIncomeConverted <= 416700.99)
                {
                    double adjusted1 = userIncomeConverted - 9325.00;
                    double adjusted2 = userIncomeConverted - 28625.00;
                    double adjusted3 = userIncomeConverted - 53950.00;
                    double adjusted4 = userIncomeConverted - 99750.00;
                    double youPay10 = 9325.00 * 0.1;
                    double youPay15 = 28625.00 * .15;
                    double youPay25 = adjusted2 * .25;
                    double youPay28 = adjusted3 * .28;
                    double youPay33 = adjusted4 * .33;
                    double finalPay = (youPay10 + youPay15 + youPay25+ youPay28+youPay33);
                    Console.WriteLine("Your income was {0:C}", userIncomeConverted);
                    youPay = (userIncomeConverted * 0.33);
                    Console.WriteLine("Tax Bracket is 33%.");
                    Console.Write("You pay ");
                    Console.WriteLine("{0:C}", youPay);
                }

                else if (userIncomeConverted >= 416701.00 && userIncomeConverted <= 418400.99)
                {
                    double adjusted1 = userIncomeConverted - 9325.00;
                    double adjusted2 = userIncomeConverted - 28625.00;
                    double adjusted3 = userIncomeConverted - 53950.00;
                    double adjusted4 = userIncomeConverted - 99750.00;
                    double adjusted5 = userIncomeConverted - 99750.00;
                    double youPay10 = 9325.00 * 0.1;
                    double youPay15 = 28625.00 * .15;
                    double youPay25 = adjusted2 * .25;
                    double youPay28 = adjusted3 * .28;
                    double youPay33 = adjusted4 * .33;
                    double youPay35 = adjusted4 * .35;
                    double finalPay = (youPay10 + youPay15 + youPay25+ youPay28+youPay33+youPay35);
                    Console.WriteLine("Your income was {0:C}", userIncomeConverted);
                    youPay = (userIncomeConverted * 0.35);
                    Console.WriteLine("Tax Bracket is 35%.");
                    Console.Write("You pay ");
                    Console.WriteLine("{0:C}", youPay);
                }

                else if (userIncomeConverted >= 410401.00)
                {
                    double adjusted1 = userIncomeConverted - 9325.00;
                    double adjusted2 = userIncomeConverted - 28625.00;
                    double adjusted3 = userIncomeConverted - 53950.00;
                    double adjusted4 = userIncomeConverted - 99750.00;
                    double adjusted5 = userIncomeConverted - 99750.00;
                    double adjusted6 = userIncomeConverted - 99750.00;
                    double youPay10 = 9325.00 * 0.1;
                    double youPay15 = 28625.00 * .15;
                    double youPay25 = adjusted2 * .25;
                    double youPay28 = adjusted3 * .28;
                    double youPay33 = adjusted4 * .33;
                    double youPay35 = adjusted4 * .35;
                    double youPay39 = adjusted4 * .396;
                    double finalPay = (youPay10 + youPay15 + youPay25+ youPay28+youPay33+youPay35+youPay39);
                    Console.WriteLine("Your income was {0:C}", userIncomeConverted);
                    youPay = (userIncomeConverted * 0.396);
                    Console.WriteLine("Tax Bracket is 39.6%.");
                    Console.Write("You pay ");
                    Console.WriteLine("{0:C}", youPay);
                }

                else
                {
                    Console.WriteLine("Your income was {0:C}", userIncomeConverted);
                    youPay = (userIncomeConverted * 0.0);
                    Console.WriteLine(".");
                    Console.Write("You pay ");
                    Console.WriteLine("{0:C}", youPay);
                }

                Console.ReadLine();
            //}
          
               

        }
    }
}


//Enter Total Income for the year (D)
//IF entry is no valid, application will send alert after computer ReadLine; Application closes
//Calculate tax rate, upon tax bracket condition, and total tax based on Reading of UserIncome
//Convert Write to string format, format dollars
//The outcome is total income tax collected, the tax bracket used in calculation, and effective tax rate
//(tax calc/total income)

