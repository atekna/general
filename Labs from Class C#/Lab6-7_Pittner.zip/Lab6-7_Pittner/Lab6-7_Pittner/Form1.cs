﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab6_7_Pittner
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string userInput = "";




            //var codeMatrix = new string[5, 5] {
            //    { "P","O","M","E","R"},
            //    { "A","N","I","B","C"},
            //    { "D","F","G","H","K"},
            //    { "L","Q","S","T","U"},
            //    { "V","W","X","Y","Z"}
            //};


            var charMatrix = new char[5, 5] {
                { 'P','O','M','E','R'},
                { 'A','N','I','B','C'},
                { 'D','F','G','H','K'},
                { 'L','Q','S','T','U'},
                { 'V','W','X','Y','Z'}
            };


            var alphabet = new char[5, 5]
               { {'A','B','C','D','E' },{'F','G','H','I','K' },{'L','M','N','O','P' },{'Q','R','S','T','U' },{'V','W','X','Y','Z'}};

           


        }


        public void MethodA() {

        }



       



        private void BTN_Clear_Click(object sender, EventArgs e)
        {
            TXT_Ciper.Clear();
            TXT_Input.Clear();
            TXT_Output.Clear();
        }


        private void BTN_Close_Click(object sender, EventArgs e)
        {
            DialogResult iExit;
            iExit = MessageBox.Show("Close the Program?", "Information Cipher", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (iExit == DialogResult.Yes)
            {
                Application.Exit();
            }
        }


        private void BTN_Translate_Click(object sender, EventArgs e)
        {
            string cipherKey = "";
            string inputResult = "";
            string outputResult = "";

            TXT_Input.Text = inputResult;
            TXT_Output.Text = outputResult;

            int index = 0;


            if (TXT_Ciper.Text == "Pomeranian")
            {

                //charMatrix[0, 0] = alphabet[0, 0];


            }




        }
    }
}
