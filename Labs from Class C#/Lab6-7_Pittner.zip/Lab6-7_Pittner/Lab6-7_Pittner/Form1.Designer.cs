﻿namespace Lab6_7_Pittner
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.LBL_Cipher = new System.Windows.Forms.Label();
            this.LBL_Input = new System.Windows.Forms.Label();
            this.LBL_Output = new System.Windows.Forms.Label();
            this.PNL_lower = new System.Windows.Forms.Panel();
            this.BTN_Translate = new System.Windows.Forms.Button();
            this.BTN_Clear = new System.Windows.Forms.Button();
            this.BTN_Close = new System.Windows.Forms.Button();
            this.TXT_Ciper = new System.Windows.Forms.TextBox();
            this.TXT_Input = new System.Windows.Forms.TextBox();
            this.TXT_Output = new System.Windows.Forms.TextBox();
            this.PNL_lower.SuspendLayout();
            this.SuspendLayout();
            // 
            // LBL_Cipher
            // 
            this.LBL_Cipher.AutoSize = true;
            this.LBL_Cipher.Font = new System.Drawing.Font("Courier New", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBL_Cipher.Location = new System.Drawing.Point(67, 59);
            this.LBL_Cipher.Name = "LBL_Cipher";
            this.LBL_Cipher.Size = new System.Drawing.Size(228, 18);
            this.LBL_Cipher.TabIndex = 0;
            this.LBL_Cipher.Text = "Cipher \"Secret\" Word: ";
            // 
            // LBL_Input
            // 
            this.LBL_Input.AutoSize = true;
            this.LBL_Input.Font = new System.Drawing.Font("Courier New", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBL_Input.Location = new System.Drawing.Point(157, 155);
            this.LBL_Input.Name = "LBL_Input";
            this.LBL_Input.Size = new System.Drawing.Size(138, 18);
            this.LBL_Input.TabIndex = 1;
            this.LBL_Input.Text = "Input Text:  ";
            // 
            // LBL_Output
            // 
            this.LBL_Output.AutoSize = true;
            this.LBL_Output.Font = new System.Drawing.Font("Courier New", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBL_Output.Location = new System.Drawing.Point(147, 234);
            this.LBL_Output.Name = "LBL_Output";
            this.LBL_Output.Size = new System.Drawing.Size(148, 18);
            this.LBL_Output.TabIndex = 2;
            this.LBL_Output.Text = "Output Text:  ";
            // 
            // PNL_lower
            // 
            this.PNL_lower.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PNL_lower.Controls.Add(this.BTN_Close);
            this.PNL_lower.Controls.Add(this.BTN_Clear);
            this.PNL_lower.Controls.Add(this.BTN_Translate);
            this.PNL_lower.Location = new System.Drawing.Point(12, 366);
            this.PNL_lower.Name = "PNL_lower";
            this.PNL_lower.Size = new System.Drawing.Size(904, 100);
            this.PNL_lower.TabIndex = 3;
            // 
            // BTN_Translate
            // 
            this.BTN_Translate.Font = new System.Drawing.Font("Courier New", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTN_Translate.Location = new System.Drawing.Point(58, 25);
            this.BTN_Translate.Name = "BTN_Translate";
            this.BTN_Translate.Size = new System.Drawing.Size(160, 53);
            this.BTN_Translate.TabIndex = 0;
            this.BTN_Translate.Text = "Translate";
            this.BTN_Translate.UseVisualStyleBackColor = true;
            this.BTN_Translate.Click += new System.EventHandler(this.BTN_Translate_Click);
            // 
            // BTN_Clear
            // 
            this.BTN_Clear.Font = new System.Drawing.Font("Courier New", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTN_Clear.Location = new System.Drawing.Point(249, 25);
            this.BTN_Clear.Name = "BTN_Clear";
            this.BTN_Clear.Size = new System.Drawing.Size(160, 53);
            this.BTN_Clear.TabIndex = 1;
            this.BTN_Clear.Text = "Clear";
            this.BTN_Clear.UseVisualStyleBackColor = true;
            this.BTN_Clear.Click += new System.EventHandler(this.BTN_Clear_Click);
            // 
            // BTN_Close
            // 
            this.BTN_Close.Font = new System.Drawing.Font("Courier New", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTN_Close.Location = new System.Drawing.Point(683, 25);
            this.BTN_Close.Name = "BTN_Close";
            this.BTN_Close.Size = new System.Drawing.Size(160, 53);
            this.BTN_Close.TabIndex = 2;
            this.BTN_Close.Text = "Close";
            this.BTN_Close.UseVisualStyleBackColor = true;
            this.BTN_Close.Click += new System.EventHandler(this.BTN_Close_Click);
            // 
            // TXT_Ciper
            // 
            this.TXT_Ciper.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.TXT_Ciper.Font = new System.Drawing.Font("Courier New", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TXT_Ciper.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.TXT_Ciper.Location = new System.Drawing.Point(346, 56);
            this.TXT_Ciper.Name = "TXT_Ciper";
            this.TXT_Ciper.Size = new System.Drawing.Size(340, 26);
            this.TXT_Ciper.TabIndex = 4;
            // 
            // TXT_Input
            // 
            this.TXT_Input.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.TXT_Input.Font = new System.Drawing.Font("Courier New", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TXT_Input.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.TXT_Input.Location = new System.Drawing.Point(346, 152);
            this.TXT_Input.Multiline = true;
            this.TXT_Input.Name = "TXT_Input";
            this.TXT_Input.Size = new System.Drawing.Size(340, 67);
            this.TXT_Input.TabIndex = 5;
            // 
            // TXT_Output
            // 
            this.TXT_Output.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.TXT_Output.Font = new System.Drawing.Font("Courier New", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TXT_Output.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.TXT_Output.Location = new System.Drawing.Point(346, 231);
            this.TXT_Output.Multiline = true;
            this.TXT_Output.Name = "TXT_Output";
            this.TXT_Output.Size = new System.Drawing.Size(340, 67);
            this.TXT_Output.TabIndex = 6;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(928, 521);
            this.Controls.Add(this.TXT_Output);
            this.Controls.Add(this.TXT_Input);
            this.Controls.Add(this.TXT_Ciper);
            this.Controls.Add(this.PNL_lower);
            this.Controls.Add(this.LBL_Output);
            this.Controls.Add(this.LBL_Input);
            this.Controls.Add(this.LBL_Cipher);
            this.Cursor = System.Windows.Forms.Cursors.Cross;
            this.Name = "Form1";
            this.Text = "Information Cipher";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.PNL_lower.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LBL_Cipher;
        private System.Windows.Forms.Label LBL_Input;
        private System.Windows.Forms.Label LBL_Output;
        private System.Windows.Forms.Panel PNL_lower;
        private System.Windows.Forms.Button BTN_Close;
        private System.Windows.Forms.Button BTN_Clear;
        private System.Windows.Forms.Button BTN_Translate;
        private System.Windows.Forms.TextBox TXT_Ciper;
        private System.Windows.Forms.TextBox TXT_Input;
        private System.Windows.Forms.TextBox TXT_Output;
    }
}

