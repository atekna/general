﻿namespace Lab4_5_Pittner
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.PNL_Central = new System.Windows.Forms.Panel();
            this.LBL_WinNotification = new System.Windows.Forms.Label();
            this.TXT_YouWins = new System.Windows.Forms.TextBox();
            this.TXT_CPUWins = new System.Windows.Forms.TextBox();
            this.LBL_YouWins = new System.Windows.Forms.Label();
            this.LBL_CPUWins = new System.Windows.Forms.Label();
            this.LBL_Computer = new System.Windows.Forms.Label();
            this.LBL_You = new System.Windows.Forms.Label();
            this.PNL_Bottom = new System.Windows.Forms.Panel();
            this.BTN_Exit = new System.Windows.Forms.Button();
            this.BTN_NewGame = new System.Windows.Forms.Button();
            this.BTN_Draw = new System.Windows.Forms.Button();
            this.PBX_ComputerStack = new System.Windows.Forms.PictureBox();
            this.PBX_YourStack = new System.Windows.Forms.PictureBox();
            this.PNL_Central.SuspendLayout();
            this.PNL_Bottom.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PBX_ComputerStack)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBX_YourStack)).BeginInit();
            this.SuspendLayout();
            // 
            // PNL_Central
            // 
            this.PNL_Central.Controls.Add(this.LBL_WinNotification);
            this.PNL_Central.Controls.Add(this.TXT_YouWins);
            this.PNL_Central.Controls.Add(this.TXT_CPUWins);
            this.PNL_Central.Controls.Add(this.LBL_YouWins);
            this.PNL_Central.Controls.Add(this.LBL_CPUWins);
            this.PNL_Central.Location = new System.Drawing.Point(386, 112);
            this.PNL_Central.Name = "PNL_Central";
            this.PNL_Central.Size = new System.Drawing.Size(479, 390);
            this.PNL_Central.TabIndex = 0;
            // 
            // LBL_WinNotification
            // 
            this.LBL_WinNotification.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.LBL_WinNotification.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBL_WinNotification.Location = new System.Drawing.Point(44, 325);
            this.LBL_WinNotification.Name = "LBL_WinNotification";
            this.LBL_WinNotification.Size = new System.Drawing.Size(397, 50);
            this.LBL_WinNotification.TabIndex = 4;
            this.LBL_WinNotification.Text = "Computer Wins";
            this.LBL_WinNotification.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // TXT_YouWins
            // 
            this.TXT_YouWins.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TXT_YouWins.Location = new System.Drawing.Point(276, 166);
            this.TXT_YouWins.Name = "TXT_YouWins";
            this.TXT_YouWins.Size = new System.Drawing.Size(100, 26);
            this.TXT_YouWins.TabIndex = 3;
            // 
            // TXT_CPUWins
            // 
            this.TXT_CPUWins.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TXT_CPUWins.Location = new System.Drawing.Point(276, 60);
            this.TXT_CPUWins.Name = "TXT_CPUWins";
            this.TXT_CPUWins.Size = new System.Drawing.Size(100, 26);
            this.TXT_CPUWins.TabIndex = 2;
            // 
            // LBL_YouWins
            // 
            this.LBL_YouWins.AutoSize = true;
            this.LBL_YouWins.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBL_YouWins.Location = new System.Drawing.Point(98, 169);
            this.LBL_YouWins.Name = "LBL_YouWins";
            this.LBL_YouWins.Size = new System.Drawing.Size(121, 20);
            this.LBL_YouWins.TabIndex = 1;
            this.LBL_YouWins.Text = "Player Victories:";
            // 
            // LBL_CPUWins
            // 
            this.LBL_CPUWins.AutoSize = true;
            this.LBL_CPUWins.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBL_CPUWins.Location = new System.Drawing.Point(71, 63);
            this.LBL_CPUWins.Name = "LBL_CPUWins";
            this.LBL_CPUWins.Size = new System.Drawing.Size(148, 20);
            this.LBL_CPUWins.TabIndex = 0;
            this.LBL_CPUWins.Text = "Computer Victories:";
            // 
            // LBL_Computer
            // 
            this.LBL_Computer.AutoSize = true;
            this.LBL_Computer.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBL_Computer.Location = new System.Drawing.Point(101, 97);
            this.LBL_Computer.Name = "LBL_Computer";
            this.LBL_Computer.Size = new System.Drawing.Size(180, 39);
            this.LBL_Computer.TabIndex = 1;
            this.LBL_Computer.Text = "Computer:";
            // 
            // LBL_You
            // 
            this.LBL_You.AutoSize = true;
            this.LBL_You.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBL_You.Location = new System.Drawing.Point(1031, 97);
            this.LBL_You.Name = "LBL_You";
            this.LBL_You.Size = new System.Drawing.Size(97, 39);
            this.LBL_You.TabIndex = 2;
            this.LBL_You.Text = "You: ";
            // 
            // PNL_Bottom
            // 
            this.PNL_Bottom.BackColor = System.Drawing.Color.SteelBlue;
            this.PNL_Bottom.Controls.Add(this.BTN_Exit);
            this.PNL_Bottom.Controls.Add(this.BTN_NewGame);
            this.PNL_Bottom.Controls.Add(this.BTN_Draw);
            this.PNL_Bottom.Location = new System.Drawing.Point(12, 555);
            this.PNL_Bottom.Name = "PNL_Bottom";
            this.PNL_Bottom.Size = new System.Drawing.Size(1240, 142);
            this.PNL_Bottom.TabIndex = 3;
            // 
            // BTN_Exit
            // 
            this.BTN_Exit.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTN_Exit.Location = new System.Drawing.Point(1075, 42);
            this.BTN_Exit.Name = "BTN_Exit";
            this.BTN_Exit.Size = new System.Drawing.Size(121, 66);
            this.BTN_Exit.TabIndex = 2;
            this.BTN_Exit.Text = "Exit";
            this.BTN_Exit.UseVisualStyleBackColor = true;
            this.BTN_Exit.Click += new System.EventHandler(this.button3_Click);
            // 
            // BTN_NewGame
            // 
            this.BTN_NewGame.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTN_NewGame.Location = new System.Drawing.Point(923, 42);
            this.BTN_NewGame.Name = "BTN_NewGame";
            this.BTN_NewGame.Size = new System.Drawing.Size(121, 66);
            this.BTN_NewGame.TabIndex = 1;
            this.BTN_NewGame.Text = "New Game";
            this.BTN_NewGame.UseVisualStyleBackColor = true;
            this.BTN_NewGame.Click += new System.EventHandler(this.BTN_NewGame_Click);
            // 
            // BTN_Draw
            // 
            this.BTN_Draw.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTN_Draw.Location = new System.Drawing.Point(65, 42);
            this.BTN_Draw.Name = "BTN_Draw";
            this.BTN_Draw.Size = new System.Drawing.Size(121, 66);
            this.BTN_Draw.TabIndex = 0;
            this.BTN_Draw.Text = "Draw Cards";
            this.BTN_Draw.UseVisualStyleBackColor = true;
            this.BTN_Draw.Click += new System.EventHandler(this.BTN_Draw_Click);
            // 
            // PBX_ComputerStack
            // 
            this.PBX_ComputerStack.BackColor = System.Drawing.Color.Green;
            this.PBX_ComputerStack.Location = new System.Drawing.Point(90, 172);
            this.PBX_ComputerStack.Name = "PBX_ComputerStack";
            this.PBX_ComputerStack.Size = new System.Drawing.Size(191, 281);
            this.PBX_ComputerStack.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.PBX_ComputerStack.TabIndex = 4;
            this.PBX_ComputerStack.TabStop = false;
            // 
            // PBX_YourStack
            // 
            this.PBX_YourStack.BackColor = System.Drawing.Color.Green;
            this.PBX_YourStack.Location = new System.Drawing.Point(981, 172);
            this.PBX_YourStack.Name = "PBX_YourStack";
            this.PBX_YourStack.Size = new System.Drawing.Size(191, 281);
            this.PBX_YourStack.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.PBX_YourStack.TabIndex = 5;
            this.PBX_YourStack.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ClientSize = new System.Drawing.Size(1264, 712);
            this.Controls.Add(this.PBX_YourStack);
            this.Controls.Add(this.PBX_ComputerStack);
            this.Controls.Add(this.PNL_Bottom);
            this.Controls.Add(this.LBL_You);
            this.Controls.Add(this.LBL_Computer);
            this.Controls.Add(this.PNL_Central);
            this.Name = "Form1";
            this.Text = "Ultimate AI War";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.PNL_Central.ResumeLayout(false);
            this.PNL_Central.PerformLayout();
            this.PNL_Bottom.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.PBX_ComputerStack)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBX_YourStack)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel PNL_Central;
        private System.Windows.Forms.Label LBL_WinNotification;
        private System.Windows.Forms.TextBox TXT_YouWins;
        private System.Windows.Forms.TextBox TXT_CPUWins;
        private System.Windows.Forms.Label LBL_YouWins;
        private System.Windows.Forms.Label LBL_CPUWins;
        private System.Windows.Forms.Label LBL_Computer;
        private System.Windows.Forms.Label LBL_You;
        private System.Windows.Forms.Panel PNL_Bottom;
        private System.Windows.Forms.Button BTN_Exit;
        private System.Windows.Forms.Button BTN_NewGame;
        private System.Windows.Forms.Button BTN_Draw;
        private System.Windows.Forms.PictureBox PBX_ComputerStack;
        private System.Windows.Forms.PictureBox PBX_YourStack;
    }
}

