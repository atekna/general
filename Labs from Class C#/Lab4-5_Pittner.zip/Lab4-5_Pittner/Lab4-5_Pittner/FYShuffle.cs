﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab4_5_Pittner
{
    public static class FYShuffle
    {
        public static void Shuffle(this object[] cardObjects)
        {

            Random random = new Random();


            for (int i = cardObjects.Length - 1; i > 0; i--)
            {
                int j = random.Next(i + 1);
                object temp = cardObjects[i];
                cardObjects[1] = cardObjects[j];
                cardObjects[j] = temp;
            }

        }
    }
}
