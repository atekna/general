﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;


namespace Lab4_5_Pittner
{
    public partial class Form1 : Form
    {
        Image[] images = new Image[52]; // This array will hold my card images.
        int[] deck = new int[52]; // This array will hold the values of each card.
        int currentCard = 0;
        Random random = new Random();

        


        public Form1()
        {
            InitializeComponent();
        }


        private void Form1_Load(object sender, EventArgs e)
        {


            DialogResult startup;
           startup = MessageBox.Show("Prepare Yourself! You are about to face me, Computer, in the ultimate card battle. I hope you know how to play 'War'. " +
                "This message will terminate after you hit the 'OK' button. ", "Ultimate AI War");




            // These three arrays are only used to construct the images and card values arrays.
            int[] values = { 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14 };

            string[] ranks = { "2", "3", "4", "5", "6", "7", "8", "9", "10", "jack", "queen", "king", "ace" };
            string[] suits = { "diamonds", "hearts", "spades", "clubs" };

            string path = @"C:\Users\germa\source\repos\cardimages\"; 

            int currentIndex = 0;

            

            //This double (nested) for loop will construct both the images and cardValues arrays. 
            //The outer loop will get the card 'ranks' (2, 3, 4 . . . Ace)
            //The inner loop constructs the 'suits' (diamonds, hearts, spades, clubs) for each card in 'ranks' (2_of_diamonds, 2_of_hearts, ace_of_clubs, etc.)
            for (int i = 0; i < (ranks.Length-1); i++)
            {
                int j = random.Next(ranks.Length + 1);
                for ( j = 0; j < suits.Length-1; j++)
                {
                    string filename = $"{path}{ranks[i]}_of_{suits[j]}.png"; // Create path to each card's image file.

                    images[currentIndex] = Image.FromFile(filename);
                    deck[currentIndex] = values[i];

                    currentIndex++;
                }
            }
        }

        public void Shuffle()
        {
        

            Random random = new Random();
            


            
        }





        //OnClick() Events

        //This should be called BTN_Exit_Click and I did change it, but it won't allow me to rename the event. I lived and learned from this.
        //Guess I will code after naming everything first.
        private void button3_Click(object sender, EventArgs e)
        {
            DialogResult iExit;
            iExit = MessageBox.Show("Would you really retreat from our battle?", "Ultimate AI War", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (iExit == DialogResult.Yes)
            {
                Application.Exit();
            }
        }



        private void BTN_NewGame_Click(object sender, EventArgs e)
        {
            TXT_CPUWins.Clear();
            TXT_YouWins.Clear();
            PBX_ComputerStack.Image = null;
            PBX_YourStack.Image = null;
        }



        private void BTN_Draw_Click(object sender, EventArgs e)
        {

            // The currentCard variable is defined in the class so that it can be referenced throughout the entire application
            // in any method. This is always pointing to the next card available from the deck.
            PBX_ComputerStack.Image = images[currentCard];
            PBX_ComputerStack.SizeMode = PictureBoxSizeMode.Zoom;
            TXT_CPUWins.Text = deck[currentCard].ToString();

            currentCard++;

            PBX_YourStack.Image = images[currentCard];
            PBX_YourStack.SizeMode = PictureBoxSizeMode.Zoom;
            TXT_YouWins.Text = deck[currentCard].ToString();

            currentCard++;


          
           


        }

    }


}
