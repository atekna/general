﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;



//As a user I want an application that will allow me to calculate
//the total cost for the installation plus the materials for a wood floor
//having specific length and width dimensions. 



namespace Lab1_Pittner
{
    class Program
    {
        static void Main(string[] args)
        {
            //Length, Width and Retail Cost of Flooring
            int length = 0;
            int width = 0;
            double retailCost = 0;

            //Two Constants
            const double _hourOfLabor = 35.75;
            const byte _feetPerHour = 40;

            
            //INPUT
            Console.Write("Please enter the length of the floor: ");
            length = Convert.ToInt32(Console.ReadLine());
            
            Console.Write("Please enter the width of the floor: ");
            width = Convert.ToInt32(Console.ReadLine());

            Console.Write("Please enter the cost per square ft. for the selected flooring: ");
            retailCost = Convert.ToDouble(Console.ReadLine());


            //Calculations
            //double result = ((length * width) * retailCost);
            double result = ((length * width) * retailCost);
            decimal r = (decimal)result;
            string rs = r.ToString("C1");

            int roomSize = length * width;

            double hoursToInstall = roomSize / _feetPerHour; //Number of Hours for Install
            decimal hti = (decimal)hoursToInstall;
            string htis = hti.ToString();

            double totalInstallCost = hoursToInstall * _hourOfLabor; //Total Install Cost
            decimal tic = (decimal)totalInstallCost;
            string tics = tic.ToString("C1");

            double overallPrice = result + totalInstallCost; //Total Cost Overall
            decimal op = (decimal)overallPrice;
            string ops = op.ToString("C1");
            
            
            //OUTPUT
            Console.WriteLine("\n\nYour Cost for a floor with the dimensions of " +length +" by " +width +" ("+roomSize+ " sq. Feet)" + " is "+rs +".");
            Console.WriteLine("The time for installation will be " + htis +"hr(s)" +" and the total costs for labor is:" +tics +".");
            Console.WriteLine ("\nOverall, your cost for the finished new flooring, including parts and labor, is:" +ops +".");
            Console.WriteLine("\n\nThis is the work of Leigh Pittner.");

           

            Console.ReadLine();

        }
    }
}
